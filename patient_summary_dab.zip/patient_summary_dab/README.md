# Patient Summary DAB Example

This is a beginner-friendly Databricks Asset Bundle (DAB) sample project.

## Structure

- databricks.yml -> deployment configuration
- resources/job.yml -> workflow orchestration
- src/*.jinja -> Spark SQL business logic
- src/*.config.yml -> table execution metadata

## Commands

Validate:
```bash
databricks bundle validate
```

Deploy:
```bash
databricks bundle deploy
```

Run:
```bash
databricks bundle run patient_pipeline
```
